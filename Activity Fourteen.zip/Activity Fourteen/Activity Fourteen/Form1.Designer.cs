﻿namespace Activity_Fourteen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ariesButton = new System.Windows.Forms.RadioButton();
            this.taurusButton = new System.Windows.Forms.RadioButton();
            this.geminiButton = new System.Windows.Forms.RadioButton();
            this.leoButton = new System.Windows.Forms.RadioButton();
            this.virgoButton = new System.Windows.Forms.RadioButton();
            this.libraButton = new System.Windows.Forms.RadioButton();
            this.scorpioButton = new System.Windows.Forms.RadioButton();
            this.sagittariusButton = new System.Windows.Forms.RadioButton();
            this.capricornButton = new System.Windows.Forms.RadioButton();
            this.aquariusButton = new System.Windows.Forms.RadioButton();
            this.piscesButton = new System.Windows.Forms.RadioButton();
            this.cancerButton = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(36, 45);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(282, 324);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Birthday Month";
            // 
            // ariesButton
            // 
            this.ariesButton.Location = new System.Drawing.Point(335, 60);
            this.ariesButton.Name = "ariesButton";
            this.ariesButton.Size = new System.Drawing.Size(85, 25);
            this.ariesButton.TabIndex = 2;
            this.ariesButton.TabStop = true;
            this.ariesButton.Text = "Aries";
            this.ariesButton.UseVisualStyleBackColor = true;
           
            // 
            // taurusButton
            // 
            this.taurusButton.AutoSize = true;
            this.taurusButton.Location = new System.Drawing.Point(451, 92);
            this.taurusButton.Name = "taurusButton";
            this.taurusButton.Size = new System.Drawing.Size(83, 24);
            this.taurusButton.TabIndex = 3;
            this.taurusButton.TabStop = true;
            this.taurusButton.Text = "Taurus";
            this.taurusButton.UseVisualStyleBackColor = true;
            // 
            // geminiButton
            // 
            this.geminiButton.AutoSize = true;
            this.geminiButton.Location = new System.Drawing.Point(560, 61);
            this.geminiButton.Name = "geminiButton";
            this.geminiButton.Size = new System.Drawing.Size(84, 24);
            this.geminiButton.TabIndex = 4;
            this.geminiButton.TabStop = true;
            this.geminiButton.Text = "Gemini";
            this.geminiButton.UseVisualStyleBackColor = true;
            // 
            // leoButton
            // 
            this.leoButton.AutoSize = true;
            this.leoButton.Location = new System.Drawing.Point(335, 91);
            this.leoButton.Name = "leoButton";
            this.leoButton.Size = new System.Drawing.Size(61, 24);
            this.leoButton.TabIndex = 5;
            this.leoButton.TabStop = true;
            this.leoButton.Text = "Leo";
            this.leoButton.UseVisualStyleBackColor = true;
            // 
            // virgoButton
            // 
            this.virgoButton.AutoSize = true;
            this.virgoButton.Location = new System.Drawing.Point(451, 122);
            this.virgoButton.Name = "virgoButton";
            this.virgoButton.Size = new System.Drawing.Size(71, 24);
            this.virgoButton.TabIndex = 6;
            this.virgoButton.TabStop = true;
            this.virgoButton.Text = "Virgo";
            this.virgoButton.UseVisualStyleBackColor = true;
            // 
            // libraButton
            // 
            this.libraButton.AutoSize = true;
            this.libraButton.Location = new System.Drawing.Point(560, 92);
            this.libraButton.Name = "libraButton";
            this.libraButton.Size = new System.Drawing.Size(69, 24);
            this.libraButton.TabIndex = 7;
            this.libraButton.TabStop = true;
            this.libraButton.Text = "Libra";
            this.libraButton.UseVisualStyleBackColor = true;
            this.libraButton.CheckedChanged += new System.EventHandler(this.libraButton_CheckedChanged);
            // 
            // scorpioButton
            // 
            this.scorpioButton.AutoSize = true;
            this.scorpioButton.Location = new System.Drawing.Point(335, 121);
            this.scorpioButton.Name = "scorpioButton";
            this.scorpioButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.scorpioButton.Size = new System.Drawing.Size(88, 24);
            this.scorpioButton.TabIndex = 8;
            this.scorpioButton.TabStop = true;
            this.scorpioButton.Text = "Scorpio";
            this.scorpioButton.UseVisualStyleBackColor = true;
            // 
            // sagittariusButton
            // 
            this.sagittariusButton.AutoSize = true;
            this.sagittariusButton.Location = new System.Drawing.Point(335, 151);
            this.sagittariusButton.Name = "sagittariusButton";
            this.sagittariusButton.Size = new System.Drawing.Size(110, 24);
            this.sagittariusButton.TabIndex = 9;
            this.sagittariusButton.TabStop = true;
            this.sagittariusButton.Text = "Sagittarius";
            this.sagittariusButton.UseVisualStyleBackColor = true;
            // 
            // capricornButton
            // 
            this.capricornButton.AutoSize = true;
            this.capricornButton.Location = new System.Drawing.Point(560, 122);
            this.capricornButton.Name = "capricornButton";
            this.capricornButton.Size = new System.Drawing.Size(102, 24);
            this.capricornButton.TabIndex = 10;
            this.capricornButton.TabStop = true;
            this.capricornButton.Text = "Capricorn";
            this.capricornButton.UseVisualStyleBackColor = true;
            // 
            // aquariusButton
            // 
            this.aquariusButton.AutoSize = true;
            this.aquariusButton.Location = new System.Drawing.Point(451, 61);
            this.aquariusButton.Name = "aquariusButton";
            this.aquariusButton.Size = new System.Drawing.Size(97, 24);
            this.aquariusButton.TabIndex = 11;
            this.aquariusButton.TabStop = true;
            this.aquariusButton.Text = "Aquarius";
            this.aquariusButton.UseVisualStyleBackColor = true;
            // 
            // piscesButton
            // 
            this.piscesButton.AutoSize = true;
            this.piscesButton.Location = new System.Drawing.Point(451, 151);
            this.piscesButton.Name = "piscesButton";
            this.piscesButton.Size = new System.Drawing.Size(80, 24);
            this.piscesButton.TabIndex = 12;
            this.piscesButton.TabStop = true;
            this.piscesButton.Text = "Pisces";
            this.piscesButton.UseVisualStyleBackColor = true;
            // 
            // cancerButton
            // 
            this.cancerButton.AutoSize = true;
            this.cancerButton.Location = new System.Drawing.Point(559, 152);
            this.cancerButton.Name = "cancerButton";
            this.cancerButton.Size = new System.Drawing.Size(85, 24);
            this.cancerButton.TabIndex = 13;
            this.cancerButton.TabStop = true;
            this.cancerButton.Text = "Cancer";
            this.cancerButton.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(36, 376);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 58);
            this.button1.TabIndex = 14;
            this.button1.Text = "Display Birthday Month";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(198, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 58);
            this.button2.TabIndex = 15;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label2.Location = new System.Drawing.Point(339, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 35);
            this.label2.TabIndex = 16;
            this.label2.Text = "Zodiac Sign";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(331, 385);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(137, 41);
            this.button3.TabIndex = 17;
            this.button3.Text = "Display Details";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(335, 255);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(116, 24);
            this.checkBox1.TabIndex = 18;
            this.checkBox1.Text = "First Name:";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(335, 285);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(112, 24);
            this.checkBox2.TabIndex = 19;
            this.checkBox2.Text = "LastName:";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(451, 257);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(188, 26);
            this.textBox1.TabIndex = 20;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(451, 289);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(188, 26);
            this.textBox2.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(331, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(348, 134);
            this.label3.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(331, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(336, 134);
            this.label4.TabIndex = 23;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(36, 440);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(282, 33);
            this.button4.TabIndex = 24;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(474, 385);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 41);
            this.button5.TabIndex = 25;
            this.button5.Text = "Clear";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(335, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 35);
            this.label5.TabIndex = 26;
            this.label5.Text = "Select Details";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 495);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cancerButton);
            this.Controls.Add(this.piscesButton);
            this.Controls.Add(this.aquariusButton);
            this.Controls.Add(this.capricornButton);
            this.Controls.Add(this.sagittariusButton);
            this.Controls.Add(this.scorpioButton);
            this.Controls.Add(this.libraButton);
            this.Controls.Add(this.virgoButton);
            this.Controls.Add(this.leoButton);
            this.Controls.Add(this.geminiButton);
            this.Controls.Add(this.taurusButton);
            this.Controls.Add(this.ariesButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton ariesButton;
        private System.Windows.Forms.RadioButton taurusButton;
        private System.Windows.Forms.RadioButton geminiButton;
        private System.Windows.Forms.RadioButton leoButton;
        private System.Windows.Forms.RadioButton virgoButton;
        private System.Windows.Forms.RadioButton libraButton;
        private System.Windows.Forms.RadioButton scorpioButton;
        private System.Windows.Forms.RadioButton sagittariusButton;
        private System.Windows.Forms.RadioButton capricornButton;
        private System.Windows.Forms.RadioButton aquariusButton;
        private System.Windows.Forms.RadioButton piscesButton;
        private System.Windows.Forms.RadioButton cancerButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label5;
    }
}

